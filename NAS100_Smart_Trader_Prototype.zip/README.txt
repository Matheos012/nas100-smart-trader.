NAS100 Smart Trader — Prototype 0.1

This is a mobile-friendly, offline-capable single-page prototype. It is a PRACTICE SIMULATOR only:
- No broker connection
- No live market feed
- No automated order execution
- No guarantee of trading results

To use on Android:
1. Download and extract the ZIP.
2. Open index.html in your browser or a file viewer that offers "Open with Chrome".
3. To put a true installable shortcut on your home screen, the site must be hosted over HTTPS. A local HTML file may not show the browser's install option.
4. The practice journal is temporary and will reset if the page is reloaded. Do not enter passwords, account IDs, or other private details.

This is not yet an APK or a live trading bot.
